#!/bin/bash
cd /opt/shadowsocks/shadowsocks
nohup python  server.py &
