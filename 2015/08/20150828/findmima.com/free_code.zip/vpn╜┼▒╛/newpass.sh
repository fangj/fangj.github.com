#!/bin/bash

kill -9 $(pidof pppd)
#如果pptpd用户在线，杀掉进程

oldpass=$(grep mima.re /etc/ppp/chap-secrets |awk -F" " {'print $3'})
echo "oldpass:$oldpass"
#配置文件中查找账号（将mima.re替换成自己的）

newpass=$(cat /dev/urandom | tr -dc A-Z0-9 | head -c 7)
echo "newpass:$newpass"
#生成随机密码

sed -i "s/$oldpass/$newpass/g" /etc/ppp/chap-secrets
# 替换密码

/etc/init.d/pptpd restart

echo "$newpass" >  /var/www/pptp_mima.txt
# 将新密码写入文件内（根据自己情况替换）