#!/bin/bash
curl http://www.mima.re/ssmima.php
