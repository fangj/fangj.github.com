<?php
$mail="abc@163.com";//这是要改密码邮箱
$conn = @mysql_connect("localhost","ss","ss");//数据库地址，用户名，密码
mysql_select_db("ss", $conn);//数据库
mysql_query("set user set 'utf8'");//user为数据库表名，数据库编码(user为ss-panel中默认的表)   
$result = mysql_query($sql);   
$pass = rand(111111,999999);//随机数字密码
$sql = "UPDATE user SET passwd = '".$pass."' WHERE email = '".$mail."'";
file_put_contents("/var/www/ss_mima.txt",$pass);  //将新密码输入到该文件
if(mysql_query($sql,$conn)){
    echo "done";
} else {
    echo "ERROR";
}
//执行后为done，说明成功

